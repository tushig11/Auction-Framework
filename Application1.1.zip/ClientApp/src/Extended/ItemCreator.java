package Extended;

import Factory.Factory;
import Model.AuctionItem;
import Observer.AuctionUser;
import Strategy.Absolute;
import Strategy.AuctionStrategy;
import model.*;

public enum ItemCreator implements Factory{
    INSTANCE;
	
	@Override
	public AuctionItem createItem() {
		return new Item();
	}

	@Override
	public AuctionStrategy createAuction() {
		return new Absolute(); 
	}

	@Override
	public AuctionUser createUser() {
		return new User();
	}
}
