package controllers;

import java.time.LocalDate;
import java.util.*;

import javax.swing.JOptionPane;

import Model.*;
import Observer.AuctionUser;
import Strategy.Absolute;
import Strategy.AuctionStrategy;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import model.User;


public class MainController {
	@FXML private ListView<AuctionItem> auctionList = new ListView<>();
	@FXML private ListView<AuctionItem> itemList = new ListView<>();;
	@FXML private ListView<String> msgList = new ListView<>();
	
	@FXML private Button bidBtn;
	@FXML private Button buyBtn;
	@FXML private Button addBtn;
	@FXML private Button upgradeBtn;
	@FXML private Button placeBtn;
	
	@FXML private TextField idTxt;
	@FXML private TextField nameTxt;
	@FXML private TextField typeTxt;
	@FXML private TextField descriptionTxt;
	
	@FXML private TextField finalTxt;
	@FXML private TextField bidTxt;
	@FXML private TextField bidValue;
	
	@FXML private DatePicker datePicker;
	

	
	private AuctionUser user;
	
	AuctionStrategy auctionStrategy = new Absolute();

	//used to add ListView elements
	ArrayList<AuctionItem> aList = new ArrayList<>();
	ArrayList<AuctionItem> iList = new ArrayList<>();
	ArrayList<String> mList = new ArrayList<>();
	
	AuctionStrategy auction = new Absolute();
	
	public void initialize(){
        System.out.println();
        System.out.println("-- Auction Quote Application --");
        System.out.println();
        
        this.user = new User("2","Bob");
        AuctionUser henok = new User("1","Henok");
        henok.pay(200);
        
        henok.createItem();
        henok.createItem();
        
        //dumb data
        List<AuctionItem> henokItems = henok.getItems();
        AuctionItem henokItem = henokItems.get(0);
        henokItem.setItemName("Trailor");
        henokItem.setItemType("Apartment");
        henokItem.setItemId("T11");
        henokItem.setItemDiscription("Nice Apartment");

        AuctionItem henokItem1 = henokItems.get(1);
        henokItem1.setItemName("Car");
        henokItem1.setItemType("Vehicle");
        henokItem1.setItemId("C13");
        henokItem1.setItemDiscription("Very nice car");
 
        
        auction.placeItemForBid(henok, henokItem, 60, LocalDate.of(2019, 8, 12), 700);
        auction.placeItemForBid(henok, henokItem1, 30, LocalDate.of(2019, 8, 14), 500);
        
        aList.addAll(auction.getItemList());
        auctionList.setItems(FXCollections.observableArrayList(aList));
	}
	
	public void addItem() {
			
		String id = idTxt.getText();
		String name = nameTxt.getText();
		String type = typeTxt.getText();
		String description = descriptionTxt.getText();
		
		List<AuctionItem> bobItems = user.getItems();
		user.createItem();
		
		System.out.println(user.getItems().size());
		AuctionItem bobItem = bobItems.get(user.getItems().size()-1);
		
        bobItem.setItemId(id);
        bobItem.setItemName(name);
        bobItem.setItemType(type);
        bobItem.setItemDiscription(description);

        
        iList.clear();
        iList.addAll(user.getItems());
        itemList.setItems(FXCollections.observableArrayList(iList));
        
	}
	
	public void bid(){
		int bid = Integer.parseInt(bidValue.getText());
		
		System.out.println(bid);
		
		if(auctionList.getSelectionModel().isEmpty()){
			JOptionPane.showMessageDialog(null, "Select ITEM First !");
		}else{
			AuctionItem selectedItem = auctionList.getSelectionModel().getSelectedItem();
			auction.bidOnItem(user, selectedItem, bid, 0);
		}
		
		printMessage();
		printAuctionItem();
	}

	public void buy() {
		if(auctionList.getSelectionModel().isEmpty()){
			JOptionPane.showMessageDialog(null, "Select ITEM First !");
		}else{
			AuctionItem selectedItem = auctionList.getSelectionModel().getSelectedItem();
			auction.bidOnItem(user, selectedItem, 0, selectedItem.getFinalPrice());
		}
		printMessage();
		printAuctionItem();
	}
	
	public void host() {
		int finalPrice = Integer.parseInt(finalTxt.getText());
		int bidPrice = Integer.parseInt(bidTxt.getText());
		LocalDate date = datePicker.getValue();
		
		
		if(itemList.getSelectionModel().isEmpty()){
			JOptionPane.showMessageDialog(null, "Select ITEM First !");
		}else{
			AuctionItem selectedItem = itemList.getSelectionModel().getSelectedItem();
			auction.placeItemForBid(user, selectedItem, bidPrice, date, finalPrice);
			
			//refresh the list
			if(!aList.contains(selectedItem)) {
				aList.add(selectedItem);
				printMessage();
			}
	        auctionList.setItems(FXCollections.observableArrayList(aList));
		}
	}
	
	public void upgrade() {
		user.pay(200);
	}
	
	public void printMessage() {
		mList.clear();
		mList.addAll(user.getNotification());
		msgList.setItems(FXCollections.observableArrayList(mList));
	}
	
	public void printAuctionItem() {
		aList.clear();
        aList.addAll(auction.getItemList());
        auctionList.setItems(FXCollections.observableArrayList(aList));
	}
}
