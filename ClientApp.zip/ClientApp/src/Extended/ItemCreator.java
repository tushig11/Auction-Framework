package Extended;

import Factory.ItemFactory;
import Model.AuctionItem;
import model.Item;

public enum ItemCreator implements ItemFactory{
    INSTANCE;
	
	@Override
	public AuctionItem createItem() {
		return new Item();
	}
}
